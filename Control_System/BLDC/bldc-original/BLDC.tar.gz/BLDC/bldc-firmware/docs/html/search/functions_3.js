var searchData=
[
  ['ee_5finit',['EE_Init',['../de/d29/group___e_e_p_r_o_m___emulation.html#ga83834957567411c76bb7f659cf8a1a38',1,'EE_Init(void):&#160;eeprom.c'],['../de/d29/group___e_e_p_r_o_m___emulation.html#ga83834957567411c76bb7f659cf8a1a38',1,'EE_Init(void):&#160;eeprom.c']]],
  ['ee_5freadvariable',['EE_ReadVariable',['../de/d29/group___e_e_p_r_o_m___emulation.html#ga0776e2e16f54d3a675e4f2f401703a85',1,'EE_ReadVariable(uint16_t VirtAddress, uint16_t *Data):&#160;eeprom.c'],['../de/d29/group___e_e_p_r_o_m___emulation.html#ga0776e2e16f54d3a675e4f2f401703a85',1,'EE_ReadVariable(uint16_t VirtAddress, uint16_t *Data):&#160;eeprom.c']]],
  ['ee_5fwritevariable',['EE_WriteVariable',['../de/d29/group___e_e_p_r_o_m___emulation.html#ga516e9ced7438b9452c72884aa1df5915',1,'EE_WriteVariable(uint16_t VirtAddress, uint16_t Data):&#160;eeprom.c'],['../de/d29/group___e_e_p_r_o_m___emulation.html#ga516e9ced7438b9452c72884aa1df5915',1,'EE_WriteVariable(uint16_t VirtAddress, uint16_t Data):&#160;eeprom.c']]],
  ['encoder_5finit',['encoder_init',['../d2/dbf/encoder_8c.html#ab885d9bad57d89e5f53eb590dc3d6011',1,'encoder_init(void):&#160;encoder.c'],['../d1/d79/encoder_8h.html#ab885d9bad57d89e5f53eb590dc3d6011',1,'encoder_init(void):&#160;encoder.c']]],
  ['encoder_5fread_5fdeg',['encoder_read_deg',['../d2/dbf/encoder_8c.html#aba853e10b5e9bbd96d72888802c36db1',1,'encoder_read_deg(void):&#160;encoder.c'],['../d1/d79/encoder_8h.html#aba853e10b5e9bbd96d72888802c36db1',1,'encoder_read_deg(void):&#160;encoder.c']]]
];
