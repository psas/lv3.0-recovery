var searchData=
[
  ['js_5fx',['js_x',['../da/d9b/structchuck__data.html#a255b264700051e2ac0f9068b70da861f',1,'chuck_data::js_x()'],['../db/d02/structmote__state.html#a00d9e512b370d0eb769ea2ebc9a0728a',1,'mote_state::js_x()']]],
  ['js_5fy',['js_y',['../da/d9b/structchuck__data.html#a7333b2e1634c12d6f5d169b7bfd6e023',1,'chuck_data::js_y()'],['../db/d02/structmote__state.html#a9e34e0672b4949584cefd0ec606cda65',1,'mote_state::js_y()']]]
];
