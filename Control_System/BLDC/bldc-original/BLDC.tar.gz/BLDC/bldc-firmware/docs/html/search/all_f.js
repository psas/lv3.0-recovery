var searchData=
[
  ['offset',['offset',['../da/d3e/struct_s_e_r_v_o.html#a13d0f87fe22730307fb653c5370d062b',1,'SERVO']]],
  ['output_5fiteration_5ftime_5fms',['OUTPUT_ITERATION_TIME_MS',['../d0/d5a/app__nunchuk_8c.html#a0c791a306562ce20ec1ad349f777da0a',1,'app_nunchuk.c']]]
];
